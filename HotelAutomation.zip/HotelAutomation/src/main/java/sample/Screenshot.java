package sample;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Screenshot {
	 public static void takeScreenshot(WebDriver driver, String name) {
	        // Create timestamp for unique file names
	        String timestamp = new SimpleDateFormat("ddMMyyyy").format(new Date());
	        String fileName = "screenshots/" + name + "_" + timestamp + ".png";
	 
	        // Take screenshot and store it as a temporary file
	        File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
	        File destFile = new File(fileName);
	 
	        // Create screenshots folder if it doesn't exist
	        destFile.getParentFile().mkdirs();
	 
	        try {
	            Files.copy(srcFile.toPath(), destFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
	            System.out.println("Screenshot saved: " + fileName);
	        } catch (IOException e) {
	            System.out.println("Failed to save screenshot: " + e.getMessage());
	        }
	    }
	}