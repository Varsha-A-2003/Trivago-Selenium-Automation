package sample;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
 
public class Launch {
	public static WebDriver driver;
	//Method to launch either Chrome or Edge based on input
	public static WebDriver launchBrowser(String browser) {
		if(browser.equalsIgnoreCase("chrome")) {
			//set path for ChromeDriver
			System.setProperty("webdriver.chrome.driver","C:\\Users\\2425552\\Downloads\\ChromeDriver\\chromedriver-win64\\chromedriver.exe");
			driver=new ChromeDriver();
		}
		else if(browser.equalsIgnoreCase("edge")) {
			//set path for EdgeDriver
			System.setProperty("webdriver.edge.driver", "C:\\Users\\2425552\\Downloads\\EdgeDriver\\msedgedriver.exe");
			driver=new EdgeDriver();
		}
		else {
			System.out.println("Unsupported browser");
		}
		//maximize window and set implicit wait
		driver.manage().window().maximize();
		return driver;
	}
	public static void closeBrowser() {
		if(driver != null) {
			driver.quit();
		}
	}
 
}
 