package sample;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;
import java.time.Duration;

public class MainClass {

    WebDriver driver;
    public static ExtentReports extent;
    public static ExtentTest test;

    @BeforeSuite
    public void setupReport() {
        // Setup for Extent HTML Report
        ExtentSparkReporter spark = new ExtentSparkReporter("TrivagoTestReport.html");
        spark.config().setTheme(Theme.DARK);
        spark.config().setDocumentTitle("Trivago Automation Report");
        spark.config().setReportName("Hotel Search and Sort Test");
        extent = new ExtentReports();
        extent.attachReporter(spark);
        extent.setSystemInfo("Tester", "Automation User");
        extent.setSystemInfo("OS", System.getProperty("os.name"));
        
        // Setup for Excel Report
        ExcelReport.createReport();
    }

    @BeforeMethod
    public void setupTest() {
        driver = Launch.launchBrowser("edge");
        driver.manage().window().maximize();
        
        // Log to both reports
        test = extent.createTest("Trivago Hotel Search and Sort Test");
        test.log(Status.PASS, "Browser launched and test started.");
        ExcelReport.log("Trivago Hotel Search and Sort", "Browser launched and test started.", "PASS");
    }

    @Test
    public void performTrivagoSearchAndSort() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));

        try {
            driver.get("https://www.trivago.in");
            test.log(Status.PASS, "Navigated to Trivago website.");
            ExcelReport.log("Trivago Hotel Search and Sort", "Navigated to Trivago website.", "PASS");
            
            // Enter city
            Thread.sleep(2000);
            Screenshot.takeScreenshot(driver, "LaunchPage");
            test.log(Status.PASS, "Took screenshot: LaunchPage");
            ExcelReport.log("Trivago Hotel Search and Sort", "Took screenshot: LaunchPage", "PASS");
            
            WebElement searchBox = wait.until(ExpectedConditions.elementToBeClickable(By.id("input-auto-complete")));
            searchBox.clear();
            searchBox.sendKeys("Mumbai");
            test.log(Status.PASS, "Entered city: Mumbai");
            ExcelReport.log("Trivago Hotel Search and Sort", "Entered city: Mumbai", "PASS");

            wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("Qrvi3L")));
            WebElement mum = driver.findElements(By.className("Qrvi3L")).get(0);
            mum.click();
            test.log(Status.PASS, "Mumbai is selected.");
            ExcelReport.log("Trivago Hotel Search and Sort", "Mumbai is selected.", "PASS");
            Thread.sleep(2000);
            Screenshot.takeScreenshot(driver, "CityPage");
            test.log(Status.PASS, "Took screenshot: CityPage");
            ExcelReport.log("Trivago Hotel Search and Sort", "Took screenshot: CityPage", "PASS");

            // Select check-in and check-out dates
            String targetDate = "2025-09-04";
            WebElement dateElement = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("time[datetime='" + targetDate + "']")));
            dateElement.click();
            test.log(Status.PASS, "Check-in date is: " + targetDate);
            ExcelReport.log("Trivago Hotel Search and Sort", "Check-in date is: " + targetDate, "PASS");
            String checkO = "2025-09-05";
            Thread.sleep(2000);
            Screenshot.takeScreenshot(driver, "CheckInDate");
            test.log(Status.PASS, "Took screenshot: CheckInDate");
            ExcelReport.log("Trivago Hotel Search and Sort", "Took screenshot: CheckInDate", "PASS");

            WebElement dateElement2 = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("time[datetime='" + checkO + "']")));
            dateElement2.click();
            test.log(Status.PASS, "Check-out date is: " + checkO);
            ExcelReport.log("Trivago Hotel Search and Sort", "Check-out date is: " + checkO, "PASS");
            Thread.sleep(2000);
            Screenshot.takeScreenshot(driver, "CheckOutDate");
            test.log(Status.PASS, "Took screenshot: CheckOutDate");
            ExcelReport.log("Trivago Hotel Search and Sort", "Took screenshot: CheckOutDate", "PASS");

            // Set Adults to 1
            WebElement adultsMinus = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"__next\"]/div[1]/div[2]/section[1]/div[2]/div/div/div[2]/div/section/div/div/div[1]/fieldset[1]/div/button[1]/span[1]")));
            adultsMinus.click();
            Thread.sleep(2000);
            Screenshot.takeScreenshot(driver, "GuestsAndRooms");
            test.log(Status.PASS, "Took screenshot: GuestsAndRooms");
            ExcelReport.log("Trivago Hotel Search and Sort", "Took screenshot: GuestsAndRooms", "PASS");

            // Click Apply
            WebElement applyBtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Apply']")));
            applyBtn.click();
            test.log(Status.PASS, "Selected 1 adult and 1 room, and clicked Apply.");
            ExcelReport.log("Trivago Hotel Search and Sort", "Selected 1 adult and 1 room, and clicked Apply.", "PASS");

            // Click the "Sort by" dropdown
            WebElement sortByDropdown = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[.//span[text()='Featured stays']]")));
            sortByDropdown.click();
            Thread.sleep(2000);
            Screenshot.takeScreenshot(driver, "SelectDropdown");
            test.log(Status.PASS, "Dropdown clicked.");
            ExcelReport.log("Trivago Hotel Search and Sort", "Dropdown clicked.", "PASS");

            // Click "Top guest ratings"
            WebElement topGuestRatings = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//label[.//text()='Top guest ratings']")));
            topGuestRatings.click();
            Thread.sleep(2000);
            Screenshot.takeScreenshot(driver, "TopRating");
            test.log(Status.PASS, "Selected 'Top guest ratings'.");
            ExcelReport.log("Trivago Hotel Search and Sort", "Selected 'Top guest ratings'.", "PASS");

            // Click the "Apply" button in the dropdown filter
            WebElement applyButton = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[text()='Apply']")));
            applyButton.click();
            test.log(Status.PASS, "Clicked 'Apply' to sort hotels.");
            ExcelReport.log("Trivago Hotel Search and Sort", "Clicked 'Apply' to sort hotels.", "PASS");

            // Wait for the filter overlay to close
            wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//button[text()='Apply']")));
            test.log(Status.PASS, "Filter overlay closed. Results are sorted.");
            ExcelReport.log("Trivago Hotel Search and Sort", "Filter overlay closed. Results are sorted.", "PASS");
            Thread.sleep(4000);

            test.log(Status.PASS, "Test completed successfully. The ratings of the hotels are expected to be in descending order.");
            ExcelReport.log("Trivago Hotel Search and Sort", "Test completed successfully.", "PASS");

        } catch (Exception e) {
            System.out.println("Test failed: "+e.getMessage());
            test.log(Status.FAIL, "Test failed due to exception: " + e.getMessage());
            ExcelReport.log("Trivago Hotel Search and Sort", "Test failed due to exception: " + e.getMessage(), "FAIL");
        }
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
            test.log(Status.PASS, "Browser closed.");
            ExcelReport.log("Trivago Hotel Search and Sort", "Browser closed.", "PASS");
        }
    }

    @AfterSuite
    public void tearDownReport() {
        if (extent != null) {
            extent.flush();
        }
        if (ExcelReport.workbook != null) {
            ExcelReport.closeReport();
        }
    }
}