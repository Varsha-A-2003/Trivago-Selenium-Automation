package sample;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.concurrent.atomic.AtomicInteger;

public class ExcelReport {

    public static Workbook workbook;
    private static Sheet sheet;
    private static AtomicInteger rowCount;
    private static String filePath = "TrivagoExcelReport.xlsx";

    public static void createReport() {
        workbook = new XSSFWorkbook();
        sheet = workbook.createSheet("Trivago Test Results");
        rowCount = new AtomicInteger(0);
        createHeaderRow();
    }

    private static void createHeaderRow() {
        Row headerRow = sheet.createRow(rowCount.getAndIncrement());
        String[] headers = {"Test Name", "Step Description", "Status", "Timestamp"};
        for (int i = 0; i < headers.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers[i]);
            CellStyle headerStyle = workbook.createCellStyle();
            Font font = workbook.createFont();
            font.setBold(true);
            headerStyle.setFont(font);
            cell.setCellStyle(headerStyle);
        }
    }

    public static void log(String testName, String stepDescription, String status) {
        Row row = sheet.createRow(rowCount.getAndIncrement());
        row.createCell(0).setCellValue(testName);
        row.createCell(1).setCellValue(stepDescription);
        row.createCell(2).setCellValue(status);
        row.createCell(3).setCellValue(java.time.LocalDateTime.now().toString());
    }

    public static void closeReport() {
        try (FileOutputStream outputStream = new FileOutputStream(filePath)) {
            workbook.write(outputStream);
            System.out.println("Excel report generated successfully at: " + filePath);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                workbook.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}